

//vars 
  var menuBtn = $('.menuBtn');
  var slidenav = $('#slidenav');
  var container = $('.container');
  var overlay = $('.overlay');
  var content = $('.content');


//Event handling
  menuBtn.click(function(){
    toggleNav();
  });

  overlay.click(function(){
    toggleNav();
  });


//toggle nav function
  function toggleNav(){
    container.toggleClass('navOut');
    overlay.toggleClass('show');
    slidenav.toggleClass('active');
    $('.sticky').toggleClass('menu-out');
  }


//Sticky nav 
$(document).ready(function() {  
  
  var stickyNavTop = $('.nav').offset().top;  

  var stickyNav = function(){  
    var scrollTop = $(window).scrollTop();       
      if (scrollTop > stickyNavTop) {   
          $('.nav').addClass('sticky');
          $('.logo img').addClass('down');
          content.addClass('marg');
      } else {  
          $('.nav').removeClass('sticky');  
          $('.logo img').removeClass('down');
            content.removeClass('marg');
      }  
  };  
  
stickyNav();  
  
  $(window).scroll(function() {  
    stickyNav();    
  });  
  
});  

 